import csv

def main():
    videojuegos = []

    try:
        cantidad = int(input("How many videogames do you want to enter? "))
    except ValueError:
        print("You must enter a number.")
        main(e)
        return

    for i in range(cantidad):
        print(f"\nVideogame #{i+1}")

        try:

            nombre = input("Name: ")
            genero = input("Genre: ")
            desarrollador = input("Developer: ")
            clasificacion = int(input("ESRB Rating: "))
            videojuegos.append([nombre, genero, desarrollador, clasificacion])
        except ValueError:
            print('Must be a number')
            main()

        

    with open("videojuegos.tsv", "w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file, delimiter="\t")

        writer.writerow(["nombre", "genero", "desarrollador", "clasificacion"])

        for juego in videojuegos:
            writer.writerow(juego)

    print("\nThe videogames were saved successfully in videojuegos.tsv")
    print('Go ahead and try another one')
    main()


if __name__ == "__main__":
    main()
