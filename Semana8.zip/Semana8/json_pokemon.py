import json

def main():
    try:
        with open("pokemon.json", "r", encoding="utf-8") as file:
            pokemons = json.load(file)

    except (FileNotFoundError, json.JSONDecodeError):
        pokemons = []

    nombre = input("Pokemon name: ")
    tipo = input("Type: ")
    hp = int(input("HP: "))

    nuevo_pokemon = {
        "name": nombre,
        "type": tipo,
        "hp": hp
    }

    pokemons.append(nuevo_pokemon)

    with open("pokemon.json", "w", encoding="utf-8") as file:
        json.dump(pokemons, file, indent=4)

    print("Pokemon added successfully!")

if __name__ == "__main__":
    main()