songs = []

with open("C:/Users/Luis/Tareas/Semana8/songs.txt", "r") as file:
    for line in file:
        songs.append(line.strip())

songs.sort()

with open("C:/Users/Luis/Tareas/Semana8/songs_sorted.txt", "w") as file:
    for song in songs:
        file.write(song + "\n")

print("Songs have been sorted and saved to songs_sorted.txt")