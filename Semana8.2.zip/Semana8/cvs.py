import csv

games_category = [
    {
        'name': 'The Legend of Zelda: Breath of the Wild',
        'gender': 'Aventura',
        'developer': 'Nintendo',
        'clasification': '10/10',
    },
    {
        'name': 'God of War (2018)',
        'gender': 'Acción',
        'developer': 'Santa Monica Studio',
        'clasification': '9.5/10',
    },
    {
        'name': 'Minecraft',
        'gender': 'Sandbox',
        'developer': 'Mojang',
        'clasification': '200 millones de copias',
    },
]

games_headers = (
    'name',
    'gender',
    'developer',
    'clasification',
)

def write_csv(path,data,header):
    with open(path, 'a+', encoding='utf-8') as file:
                file.seek(0)
                writer = csv.DictWriter(file,header)
                firts_character = file.read(1)
                if not firts_character:
                    writer.writeheader()
                    writer.writerows(data)
                else:
                    file.seek(0,2)
                     
                while True:
                    try:
                        name = input('Give me the name: ')
                        gender = input('Give me the gender: ')
                        developer = input('Give me the developer: ')
                        clasification = int(input('Give me the clasification from 1 to 10: ' ))
                        new_game = {
                            'name': name,
                            'gender': gender,
                            'developer': developer,
                            'clasification': clasification
                        }
                        data.append(new_game)
                        writer.writerow(new_game)
                        file.flush()
                        print('Game added, please add another one!!')
                    except ValueError:
                        print('error on clasification,please need to be a number')



write_csv('games_categorys.csv', games_category, games_headers)