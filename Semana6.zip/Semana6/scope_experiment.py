def scope():
    y = 5

scope()
print(y)

number = 60

def global_scope():
    number = 30

global_scope()
print(number)


#Claramente la primera funcion no funciona, pero la segunda si
