import csv

def get_number_of_games():
    while True:
        try:
            return int(input("How many videogames do you want to enter? "))
        except ValueError:
            print("You must enter a number.")

def get_game_info():
    name = input("Name: ")
    genre = input("Genre: ")
    developer = input("Developer: ")
    while True:
        try:
            rating = int(input("ESRB Rating: "))
            break
        except ValueError:
            print("Must be a number.")
    return [name, genre, developer, rating]

def save_to_csv(games_list, filename="videojuegos.csv"):
    with open(filename, "w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["name", "genre", "developer", "rating"])
        for game in games_list:
            writer.writerow(game)

def main():
    games = []
    amount = get_number_of_games()
    
    for i in range(amount):
        print(f"\nVideogame #{i+1}")
        game = get_game_info()
        games.append(game)
        
    save_to_csv(games)
    print("\nThe videogames were saved successfully in videojuegos.csv")

if __name__ == "__main__":
    main()