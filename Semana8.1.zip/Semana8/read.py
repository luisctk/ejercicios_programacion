def read_songs(filepath):
    songs = []
    try:
        with open(filepath, "r") as file:
            for line in file:
                songs.append(line.strip())
    except FileNotFoundError:
        print("File not found.")
    return songs

def sort_items(items):
    items.sort()
    return items

def write_songs(filepath, items):
    with open(filepath, "w") as file:
        for item in items:
            file.write(item + "\n")

def main():
    input_path = "C:/Users/Luis/Tareas/Semana8/songs.txt"
    output_path = "C:/Users/Luis/Tareas/Semana8/songs_sorted.txt"
    
    songs_list = read_songs(input_path)
    
    if songs_list:
        sorted_songs = sort_items(songs_list)
        write_songs(output_path, sorted_songs)
        print("Songs have been sorted and saved to songs_sorted.txt")

if __name__ == "__main__":
    main()